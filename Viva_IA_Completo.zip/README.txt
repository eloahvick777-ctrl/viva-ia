VIVA IA - PROJETO BASE
=======================

Esta pasta contém a versão inicial completa do projeto:
- site responsivo para celular
- frontend de chat
- backend seguro para chamada da OpenAI
- limite diário básico para usuários
- estrutura preparada para Premium e monetização

IMPORTANTE:
1. Não coloque sua chave da API no index.html.
2. Crie um arquivo .env a partir de .env.example.
3. Coloque sua chave somente no servidor.
4. O backend usa a Responses API.
5. Antes de publicar para outras pessoas, troque o armazenamento em memória por um banco de dados e implemente autenticação/pagamentos.

Como executar em um ambiente Node.js:
npm install
copie .env.example para .env
adicione sua OPENAI_API_KEY no .env
npm start

Depois abra o endereço informado pelo servidor.

Esta versão é uma base de desenvolvimento. Ela não inclui uma chave de API, pagamento ou anúncios reais.
