import express from "express";
import dotenv from "dotenv";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;
const dailyLimit = Number(process.env.DAILY_LIMIT || 10);
const model = process.env.OPENAI_MODEL || "gpt-5-mini";

if (!process.env.OPENAI_API_KEY) {
  console.warn("OPENAI_API_KEY não configurada. Crie um arquivo .env.");
}

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const usage = new Map();

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(path.dirname(fileURLToPath(import.meta.url)), "public")));

function getClientKey(req) {
  // Apenas identificador temporário para a demonstração.
  // Em produção, use autenticação e banco de dados.
  return req.ip || "demo-user";
}

function resetIfNeeded(record) {
  const today = new Date().toISOString().slice(0, 10);
  if (!record || record.date !== today) return { date: today, count: 0 };
  return record;
}

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();

    if (!message) {
      return res.status(400).json({ error: "Digite uma mensagem." });
    }

    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({
        error: "A chave da API ainda não foi configurada no servidor."
      });
    }

    const key = getClientKey(req);
    let record = resetIfNeeded(usage.get(key));

    if (record.count >= dailyLimit) {
      return res.status(429).json({
        error: `Limite gratuito diário atingido (${dailyLimit} mensagens).`
      });
    }

    const response = await client.responses.create({
      model,
      instructions:
        "Você é o Viva IA, um assistente útil, claro, educado e responsável. Responda em português do Brasil quando o usuário escrever em português.",
      input: message
    });

    record.count += 1;
    usage.set(key, record);

    res.json({
      answer: response.output_text || "Não consegui gerar uma resposta.",
      remaining: Math.max(0, dailyLimit - record.count)
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      error: "Ocorreu um erro ao conversar com o Viva IA."
    });
  }
});

app.get("/api/status", (req, res) => {
  const key = getClientKey(req);
  const record = resetIfNeeded(usage.get(key));
  res.json({
    dailyLimit,
    used: record.count,
    remaining: Math.max(0, dailyLimit - record.count)
  });
});

app.listen(port, () => {
  console.log(`Viva IA rodando em http://localhost:${port}`);
});
